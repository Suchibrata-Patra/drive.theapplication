<?php
session_start([
    'use_cookies' => 1,
    'use_only_cookies' => 0,
    'use_trans_sid' => 1
]);

session_set_cookie_params(0);

$correctPassword = "2003";
$showGif = false; // Variable to track if GIF should be shown

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if ($_POST["password"] === $correctPassword) {
        $_SESSION["authenticated"] = true;
        $showGif = true; // Set GIF to show after success
    } else {
        $error = "Incorrect password!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TheApplication</title>
<meta name="description" content="TheApplication Drive is a secure, private, and fast cloud storage solution. Store and access your files anywhere. A perfect alternative to Google Drive.">
<meta name="keywords" content="TheApplication Drive, Secure Cloud Storage, Private Cloud Drive, File Storage Solution, Google Drive Alternative">
<meta name="robots" content="index, follow">
<meta name="author" content="Suchibrata Patra">

<!-- Open Graph for Social Media Sharing -->
<meta property="og:title" content="TheApplication Drive - Secure Cloud Storage">
<meta property="og:description" content="Store your files securely on TheApplication Drive. A reliable and fast personal cloud storage solution.">
<meta property="og:image" content="https://drive.theapplication.in/drive-thumbnail.jpg">
<meta property="og:url" content="https://drive.theapplication.in/">
<meta property="og:type" content="website">

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="TheApplication Drive - Cloud Storage">
<meta name="twitter:description" content="A secure and fast cloud storage solution. Access and manage your files anywhere.">
<meta name="twitter:image" content="https://drive.theapplication.in/drive-thumbnail.jpg">

<!-- Canonical URL -->
<link rel="canonical" href="https://drive.theapplication.in/">

<!-- JSON-LD Structured Data -->
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": "TheApplication Drive",
    "url": "https://drive.theapplication.in/",
    "description": "TheApplication Drive is a private and secure cloud storage solution for storing and managing your files."
}
</script>

<link rel="icon" href="https://drive.theapplication.in/icons/cloud.png" type="image/png">
<link rel="shortcut icon" href="https://drive.theapplication.in/favicon.ico" type="image/x-icon">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: #ffffff;
        }
        .login-container {
            background: #ffffff;
            padding: 50px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            text-align: center;
            width: 600px;
            height:600px;
        }
        .logo {
            width:280px;
            margin-bottom: 20px;
        }
        h2 {
            margin-bottom: 20px;
            color: #1d1d1f;
            font-weight: 600;
            font-size: 26px;
        }
        .input-container {
            position: relative;
            width: 100%;
        }
        input {
            width: 100%;
            padding: 14px;
            padding-right: 40px;
            border: 1px solid  #fad648;
            border-radius: 12px;
            font-size: 18px;
            background: #f5f5f7;
            outline: none;
            transition: 0.3s ease-in-out;
        }
        input:focus {
            border-color: #0071e3;
            background: #ffffff;
        }
        .arrow-button {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: transparent;
            border: none;
            cursor: pointer;
            font-size: 24px;
            color: #0071e3;
        }
        /* Navbar Styling */
.navbar {
    width: 100%;
    height: 60px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 20px;
    background: white;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    font-size: 18px;
    font-weight: 500;
    position: fixed;
    top: 0;
    left: 0;
}

.navbar-left {
    font-size: 22px;
}

.apple-logo {
    font-family: "SF Pro Display", sans-serif;
    font-weight: bold;
}

.menu-icon {
    font-size: 24px;
    cursor: pointer;
}

.login-container {
    margin-top: 40px;
}

    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-left">
            <span class="apple-logo"><img src="https://upload.wikimedia.org/wikipedia/commons/6/63/The_application.in_navbara_icon.png" alt="" style="width:140px;"></span>
            <!-- <span class="apple-logo">Forbidden </span>Drive -->
        </div>
        <div class="navbar-right">
            <span class="menu-icon">...</span>
        </div>
    </nav>
    <div class="login-container">
<video class="logo" autoplay loop muted>
    <source src="/icons/login.mp4" type="video/mp4">
    Your browser does not support the video tag.
</video>
        <h2>Welcome Back Suchibrata</h2>
        <form method="POST">
            <div class="input-container" style="display:flex;justify-content:center;">
                <input type="password" name="password" placeholder="Enter your password" required>
                <button type="submit" class="arrow-button">
    <span class="material-symbols-outlined" style="font-size:2rem;color:rgb(113, 113, 113);font-weight:100!important;">
        arrow_circle_right
    </span>
</button>

            </div>
            <!-- <div style="color:grey;margin-top:30px;font-size:0.3rem;">
                Designed And Developed by Suchibrata
            </div> -->
        </form>
         <div class="gif-container <?php echo $showGif ? '' : 'hidden'; ?>">
            <img src="https://drive.theapplication.in/verification.gif" alt="Success Animation" width="0">
        </div>
        <!--<div style="margin-top:50px;">-->
        <!--    <a href="#" style="color:#1471e3;font-size:0.9rem;text-decoration:none;display:inline-block;">Privacy Policy</a>-->
        <!--</div>-->
    </div>
</body>
</html>


