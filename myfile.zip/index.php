<?php
session_start();
// Redirect to login if not authenticated
if (!isset($_SESSION["authenticated"])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suchi's Drive</title>
    <link rel="icon" type="image/x-icon" href="/icons/cloud.png">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            display: flex;
            height: 100vh;
            background: #e0e5ec;
        }

        /* Sidebar */
        /* .sidebar {
            width: 20%;
            background: #e8eaed;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            box-shadow: 10px 0px 20px #d2d7e1, -10px -10px 20px #ffffff;
        } */
        .sidebar {
            z-index: 100;
            width: 250px;
            background: #e8eaed;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            box-shadow: 10px 0px 20px #d2d7e1, -10px -10px 20px #ffffff;
            position: fixed;
            height: 100vh;
            left: 0;
            transition: transform 0.3s ease-in-out;
        }

        .sidebar.collapsed {
            transform: translateX(-100%);
        }

        .toggle-btn {
            position: fixed;
            top: 0px;
            left: 0px;
            background: none;
            color: rgb(14, 113, 170);
            padding: 2px 10px 5px 10px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            z-index: 1000;
            font-size: 25px;
            font-weight: 400;
        }

        .sidebar h2 {
            margin-bottom: 20px;
        }

        .upload-box {
            background: #e0e5ec;
            padding: 20px;
            border-radius: 10px;
            /* border: 2px solid rgb(18, 140, 210); */
            /* box-shadow: inset 5px 5px 10px #babecc, inset -5px -5px 10px #ffffff; */
            width: 100%;
            text-align: center;
        }

        input[type="file"] {
            margin: 15px 0;
            padding: 10px;
            width: 100%;
            border: none;
            outline: none;
            background: #e0e5ec;
            border-radius: 10px;
            font-size: 14px;
            cursor: pointer;
        }

        button {
            padding: 12px 20px;
            border: none;
            background: #e0e5ec;
            border-radius: 0px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }

        button:hover {
            /* box-shadow: inset 5px 5px 10px #babecc, inset -5px -5px 10px #ffffff; */
        }

        #status {
            margin-top: 10px;
            font-weight: bold;
            font-size: 14px;
            color: #333;
        }

        /* File Display Section */
        .file-section {
            flex: 1;
            padding: 30px;
            overflow-y: auto;
        }

        .file-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .file-box {
            width: 120px;
            height: 150px;
            background: #ffffff;
            border-radius: 6px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 1px 20px 10px 20px;
            box-shadow:
                0px 10px 30px rgba(0, 0, 0, 0.1),
                /* Soft diffused shadow */
                0px 4px 6px rgba(0, 0, 0, 0.05);
            /* Subtle secondary shadow */
        }

        .file-box img {
            width: auto;
            height: 40px;
            margin-bottom: 8px;
        }

        .file-box a {
            font-size: 0.8rem;
            text-decoration: none;
            color: #000000;
            font-weight: 300;
            word-wrap: break-word;
        }

        .menu-container {
            position: absolute;
            top: 0px;
            right: 0px;
        }

        .menu-btn {
            background: none;
            border: none;
            font-size: 18px;
            cursor: pointer;
            padding-top: 0.5rem;
            padding-right: 0.5rem;
        }

        .upload_button {
            border: 1px solid #1471e3;
            border-radius: 50px;
            /* padding-top: 7px;
            padding-bottom: 7px; */
            margin-top: 3px;
            color: #0f5ec0;
            font-weight: 400;

        }

        .upload_button:hover {
            background-color: #1471e3;
            color: white;
        }

        .menu-content {
            display: none;
            position: absolute;
            right: -20px;
            top: 2rem;
            background: #ffffff;
            box-shadow: 10px 0px 20px #d2d7e1, -10px -10px 20px #ffffff;
            min-width: 100px;
            border-radius: 10px;
            z-index: 1;
        }

        .menu-content button {
            width: 100%;
            border: none;
            background: none;
            /* padding:2px 2px 12px 2px; */
            background-color: rgb(220, 220, 220);
            color: black;
            /* border-radius: 10px; */
            text-align: left;
            cursor: pointer;
            font-size: 0.8rem;
            font-weight: 500;
        }

        .menu-content button:hover {
            background: #cdcdcd;
        }

        /* Show menu when clicked */
        .menu-content.show {
            display: block;
            border-radius: 10px;
        }

        /* Ensure .file-box is positioned properly */
        .file-box {
            position: relative;
            padding-top: 25px;
        }

        .custom-file-button {
            display: inline-block;
            background: #1471e3;
            border: none;
            color: rgb(255, 255, 255);
            padding: 12px 20px;
            border-radius: 50px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 300;
            text-align: center;
            transition: 0.3s ease-in-out;
        }

        .custom-file-button:hover {
            background: #1977ea;
        }

        .search-bar {
            margin-top: 7px;
            margin-left: 11%;
            padding: 12px 40% 12px 1%;
            font-weight: 300;
            color: rgb(0, 0, 0);
            border: 0.5px solid rgb(107, 107, 107);
            margin-bottom: 2%;
            border-radius: 10px;
        }

        .search-bar::placeholder {
            font-size: 1rem;
            color: rgb(140, 140, 140);
        }

        .loader {
            display: inline-block;
            animation: rotate 1s linear infinite;
        }

        @media screen and (min-width: 768px) {
            .sidebar {
                width: 250px;
                position: fixed;
                left: 0;
                height: 100vh;
                transform: translateX(0);
                /* Always visible on desktop */
            }

            .file-section {
                margin-left: 250px;
                /* Prevent overlap on desktop */
            }

            .toggle-btn {
                display: none;
                /* Hide toggle button on desktop */
            }
        }

        @media screen and (max-width: 767px) {
            .sidebar {
                width: 250px;
                transform: translateX(-100%);
                transition: transform 0.3s ease-in-out;
            }

            .sidebar.collapsed {
                transform: translateX(0);
            }

            .toggle-btn {
                display: block;
            }

            .file-section {
                margin-left: 0;
                /* Full width when sidebar is collapsed */
            }
        }


        @keyframes rotate {
            from {
                transform: rotate(0deg);
            }

            to {
                transform: rotate(360deg);
            }
        }

        @media screen and (max-width: 768px) {
            .sidebar {
                width: 250px;
                transform: translateX(-100%);
                height: 99vh;
            }

            .sidebar.collapsed {
                transform: translateX(0);
            }

            .toggle-btn {
                display: block;
            }

            .file-container {
                gap: 6px;
            }

            .file-section {
                padding: 0px 0px 0px 13px;
            }

            .file-box {
                width: calc(33.33% - 13.33px);
                /* Adjust for the spacing */
                height: 120px;
            }
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal-content {
            background-color: white;
            margin: 10% auto;
            padding: 20px;
            width: 240px;
            text-align: center;
            border-radius: 5px;
        }

        .close {
            color: red;
            /* float: right; */
            font-size: 24px;
            cursor: pointer;
            margin-left: 25%;
        }
    </style>
</head>

<body>
    <div id="qrModal" class="modal">
        <div class="modal-content">
            <h4 style="padding: 10px 10px 2px 10px;color: rgb(25, 73, 163);">Scan Me :)</h4>
            <p id="qrFilename" style="font-size:1rem; font-weight: 200; color:rgb(90, 149, 0);margin-bottom: 7px;"></p>
            <div id="qrcode"></div>
        </div>
    </div>


    <script>
        // Function to close the modal when clicking outside
        window.onclick = function (event) {
            const modal = document.getElementById("qrModal");
            if (event.target === modal) {
                modal.style.display = "none";
            }
        };

        // function shareQR(url) {
        //     // Open the modal
        //     document.getElementById('qrModal').style.display = 'block';

        //     // Clear any existing QR code
        //     document.getElementById('qrcode').innerHTML = '';

        //     // Generate the QR code
        //     new QRCode(document.getElementById('qrcode'), {
        //         text: url,
        //         width: 200,
        //         height: 200
        //     });
        // }
        function shareQR(url, filename) {
            // Open the modal
            document.getElementById('qrModal').style.display = 'block';

            // Set the filename below "Scan Me!"
            document.getElementById('qrFilename').innerText = filename;

            // Clear any existing QR code
            document.getElementById('qrcode').innerHTML = '';

            // Generate the QR code
            new QRCode(document.getElementById('qrcode'), {
                text: url,
                width: 200,
                height: 200
            });
        }
        // Function to close the QR modal manually
        function closeQRModal() {
            document.getElementById('qrModal').style.display = 'none';
        }
    </script>
    <button class="toggle-btn" onclick="toggleSidebar()">☰</button>
    <script>
        function toggleSidebar() {
            document.querySelector(".sidebar").classList.toggle("collapsed");
        }
    </script>
    <div class="file-section">
        <input type="text" id="searchBar" class="search-bar" placeholder="Search Files..." onkeyup="searchFiles()">
        <div class="file-container" id="fileList"></div>
    </div>
    <div class="sidebar">
        <img src="/icons/cloud.png" alt="Cloud" style="width: 70px; height: auto;">
        <div class="upload-box" style="display: flex;flex-direction: column;">
            <input type="file" id="fileInput" multiple hidden>
            <label for="fileInput" class="custom-file-button">Choose File</label>
            <button onclick="uploadFile()" class="upload_button">Upload</button>
            <p id="status"></p>
        </div>
        <p id="totalSize" style="margin-top: 20px; font-weight: 300; color: #000000;">Used: 0 KB</p>
        <h4 style="margin-top:10px;font-weight">Selected Files</h4>
    <ul id="selectedFilesList" style="font-weight:300;font-size:0.7rem;color:grey;">
        <li style="display:none;">No files selected</li>
    </ul>
        <div
            style="position: fixed; bottom: 20px; color: rgb(181, 181, 181); font-weight: 200; display: flex;flex-direction: column ;align-items: center;">
            <a href="logout.php" style="text-decoration: none;">
                <button
                    style="background: rgb(0, 0, 0); color: rgb(255, 255, 255); border: 2px solid black; padding: 8px 16px; border-radius: 50px; cursor: pointer;font-weight: 300 !important;display: flex;justify-content: center;align-items: center;text-decoration: none;">
                    Logout
                </button>
            </a>
            <span style="margin-top: 5px;">Developed by S. Patra</span>
        </div>

    </div>
    <script>
        async function fetchFiles() {
            try {
                const response = await fetch("upload.php");
                const data = await response.json();
                const fileListElement = document.getElementById("fileList");
                const totalSizeElement = document.getElementById("totalSize");

                let totalSize = 0;

                if (data.status === "success") {
                    fileListElement.innerHTML = "";
                    data.files.forEach(file => {
                        totalSize += file.size; // Sum up all file sizes

                        const fileBox = document.createElement("div");
                        fileBox.className = "file-box";

                        // Get file extension and determine icon
                        const fileExtension = file.name.split('.').pop().toLowerCase();
                        let icon;

                        switch (fileExtension) {
                            case "jpg": case "jpeg": case "png": case "svg": case "gif":
                                icon = "image-logo.png";
                                break;
                            case "pdf":
                                icon = "pdf_icon.png";
                                break;
                            case "zip": case "rar":
                                icon = "zip_icon.png";
                                break;
                            case "mp4": case "mkv": case "avi":
                                icon = "video-icon.png";
                                break;
                            case "mp3": case "wav":
                                icon = "music-icon.png";
                                break;
                            case "r":
                                icon = "r_icon.png";
                                break;
                            case "zip":
                                icon = "zip_logo.png";
                                break;
                            case "ipynb":
                                icon = "jupyter_logo.png";
                                break;
                            case "xls": case "numbers": case "xlsx": case "csv": case "xlsm": case "xltx": case "xltm":
                                icon = "excel_icon.png";
                                break;
                            case "ppt": case "pptx": case "key":
                                icon = "ppt_icon.png";
                                break;
                            case "py":
                                icon = "python_logo.png";
                                break;
                            default:
                                icon = "default_file.png";
                        }

                        const fileUrl = file.url;
                        const truncatedName = file.name.length > 20 ? file.name.substring(0, 17) + "..." : file.name;

                        fileBox.innerHTML = `
    <div class="menu-container">
        <button class="menu-btn" onclick="toggleMenu(this)">⋮</button>
        <div class="menu-content">
            <button onclick="deleteFile('${file.name}', this)">Delete</button>
<button onclick="shareQR('${fileUrl}', '${file.name}')">QR Code</button>
        </div>
    </div>
    <img src="icons/${icon}" alt="File Icon">
    <a href="${fileUrl}" target="_blank" title="${file.name}">${truncatedName}</a>
`;

                        fileListElement.appendChild(fileBox);
                    });
                } else {
                    fileListElement.innerHTML = "<p>No files uploaded yet.</p>";
                }

                // Convert total file size to readable format
                function formatSize(bytes) {
                    if (bytes < 1024) return `${bytes} B`;
                    if (bytes < 1048576) return `${(bytes / 1024).toFixed(2)} KB`;
                    if (bytes < 1073741824) return `${(bytes / 1048576).toFixed(2)} MB`;
                    return `${(bytes / 1073741824).toFixed(2)} GB`;
                }

                totalSizeElement.innerHTML = `Storage Used: <b style='font-weight:500;'>${formatSize(totalSize)}</b>`;
            } catch (error) {
                console.error("Error fetching files:", error);
            }
        }

        // Toggle Menu Function
        function toggleMenu(button) {
            const menuContent = button.nextElementSibling;
            menuContent.classList.toggle("show");
        }

        // Delete File Function
        async function deleteFile(fileName, button) {
            if (confirm(`Are you sure you want to delete "${fileName}"?`)) {
                try {
                    const response = await fetch(`upload.php?file=${encodeURIComponent(fileName)}`, {
                        method: "DELETE",
                    });

                    const data = await response.json();

                    if (data.status === "success") {
                        alert(`Deleted: ${fileName}`);
                        button.closest(".file-box").remove();
                    } else {
                        alert(`Error deleting file: ${data.message}`);
                    }
                } catch (error) {
                    console.error("Error deleting file:", error);
                }
            }
        }

        // Close any open menus when clicking outside
        document.addEventListener("click", function (event) {
            if (!event.target.matches(".menu-btn")) {
                document.querySelectorAll(".menu-content").forEach(menu => {
                    menu.classList.remove("show");
                });
            }
        });

        // Upload File Function
        function uploadFile() {
            const fileInput = document.getElementById("fileInput");
            const statusElement = document.getElementById("status");

            if (!fileInput.files.length) {
                alert("Please select at least one file.");
                return;
            }

            const formData = new FormData();
            for (let file of fileInput.files) {
                formData.append("files[]", file);
            }

            // Add rotating loader animation
            statusElement.innerHTML = `Uploading... <span class="loader">⏳</span>`;

            fetch("upload.php", { method: "POST", body: formData })
                .then(response => response.json())
                .then(data => {
                    statusElement.innerHTML = `<span style="color: green;">✅ Upload Complete!</span>`;
                    fetchFiles();
                })
                .catch(error => {
                    statusElement.innerHTML = `<span style="color: red;">❌ Upload Failed!</span>`;
                    console.error("Upload error:", error);
                });
        }

        // Search Files Function
        function searchFiles() {
            const searchQuery = document.getElementById("searchBar").value.toLowerCase();
            document.querySelectorAll(".file-box").forEach(box => {
                box.style.display = box.querySelector("a").textContent.toLowerCase().includes(searchQuery) ? "flex" : "none";
            });
        }

        // Fetch files when the page loads
        window.addEventListener("load", fetchFiles);
       
       
       //Shows the Selected Fiels
        document.getElementById("fileInput").addEventListener("change", function (event) {
    const fileList = document.getElementById("selectedFilesList");
    fileList.innerHTML = ""; // Clear previous list

    const files = event.target.files; // Get selected files
    if (files.length > 0) {
        for (let i = 0; i < files.length; i++) {
            const fileName = files[i].name;
            const listItem = document.createElement("li");
            listItem.textContent = fileName;
            fileList.appendChild(listItem);
        }
    } else {
        const noFilesMessage = document.createElement("li");
        noFilesMessage.textContent = "No files selected";
        fileList.appendChild(noFilesMessage);
    }
});

    </script>
</body>

</html>