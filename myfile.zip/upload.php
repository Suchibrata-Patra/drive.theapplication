<?php
$githubUsername = "Suchibrata-Patra";
$githubRepo = "drive.theapplication";
$githubBranch = "main";
$githubToken = "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";

header("Content-Type: application/json");

function githubApiRequest($url, $method = "GET", $data = null)
{
    global $githubToken;
    $headers = [
        "Authorization: token $githubToken",
        "Accept: application/vnd.github.v3+json",
        "User-Agent: FileUploader"
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    if ($data) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    }

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return ($httpCode >= 200 && $httpCode < 300) ? json_decode($response, true) : false;
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_FILES['files'])) {
    $uploadResponses = [];
    foreach ($_FILES['files']['tmp_name'] as $index => $tmpName) {
        $fileName = basename($_FILES['files']['name'][$index]);
        $fileContent = base64_encode(file_get_contents($tmpName));
        $githubPath = "contents/$fileName";
        $uploadUrl = "https://api.github.com/repos/$githubUsername/$githubRepo/$githubPath";

        $data = [
            "message" => "Upload $fileName",
            "content" => $fileContent,
            "branch" => $githubBranch
        ];

        $response = githubApiRequest($uploadUrl, "PUT", $data);
        if ($response) {
            $uploadResponses[] = [
                "name" => $fileName,
                "url" => $response['content']['html_url'],
                "size" => $_FILES['files']['size'][$index]
            ];
        }
    }
    echo json_encode(["status" => "success", "files" => $uploadResponses]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $filesUrl = "https://api.github.com/repos/$githubUsername/$githubRepo/contents/";
    $files = githubApiRequest($filesUrl);
    
    $fileList = [];
    if ($files) {
        foreach ($files as $file) {
            if ($file['type'] === "file") {
                $fileList[] = [
                    "name" => $file['name'],
                    "url" => $file['download_url'],
                    "size" => $file['size']
                ];
            }
        }
    }
    echo json_encode(["status" => "success", "files" => $fileList]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "DELETE") {
    $fileName = $_GET['file'] ?? null;
    if (!$fileName) {
        echo json_encode(["status" => "error", "message" => "No file specified"]);
        exit;
    }

    $fileUrl = "https://api.github.com/repos/$githubUsername/$githubRepo/contents/$fileName";
    $fileData = githubApiRequest($fileUrl);

    if (!$fileData || !isset($fileData['sha'])) {
        echo json_encode(["status" => "error", "message" => "File not found"]);
        exit;
    }

    $deleteData = [
        "message" => "Delete $fileName",
        "sha" => $fileData['sha'],
        "branch" => $githubBranch
    ];

    $response = githubApiRequest($fileUrl, "DELETE", $deleteData);
    if ($response) {
        echo json_encode(["status" => "success", "message" => "$fileName deleted"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to delete $fileName"]);
    }
    exit;
}

echo json_encode(["status" => "error", "message" => "Invalid request"]);
?>